// Báo cáo · in nội dung xem trước (ES module, import từ ReportDialog.razor).
//
// TẠM THỜI thay cho file PDF từ API: người dùng chọn "Lưu dưới dạng PDF" trong hộp thoại in.
//
// Cách in: KHÔNG dùng iframe (bản iframe in ra trang trắng trên app thật — CSS/font của trang
// không áp đủ trong iframe). Thay vào đó in ngay trên trang hiện tại:
//   1. clone phần tử xem trước (giữ class + thuộc tính b-xxx của CSS isolation) vào <div id=swms-print-root>
//      gắn thẳng dưới <body>, ngoài vùng Blazor quản lý;
//   2. @media print: ẩn mọi thứ khác dưới <body>, chỉ in #swms-print-root;
//   3. window.print(), xong (afterprint) gỡ root + style, trả lại document.title.
// document.title tạm = tên file gợi ý khi lưu PDF.

const ROOT_ID = 'swms-print-root';
const STYLE_ID = 'swms-print-style';

const PRINT_CSS = `
#${ROOT_ID} { display: none; }
@media print {
  /* margin 0 -> trình duyệt không còn chỗ in header / footer (ngày, tiêu đề, URL, số trang).
     Lề thật: padding 2 bên + hàng đệm thead / tfoot của bảng khung .pp lặp lại mỗi trang. */
  @page { size: A4 portrait; margin: 0; }
  /* layout của app hay khoá chiều cao / overflow -> bản in chỉ 1 trang hoặc trắng */
  html, body {
    height: auto !important; min-height: 0 !important; max-height: none !important;
    overflow: visible !important; display: block !important; background: #fff !important;
  }
  body > *:not(#${ROOT_ID}) { display: none !important; }
  #${ROOT_ID} { display: block !important; position: static !important; }
  #${ROOT_ID}, #${ROOT_ID} * {
    -webkit-print-color-adjust: exact; print-color-adjust: exact;
    animation: none !important; transition: none !important;
  }
  #${ROOT_ID} { padding: 0 8mm !important; }
  #${ROOT_ID} > table.pp { width: 100%; border-collapse: collapse; border: 0; }
  #${ROOT_ID} > table.pp > thead { display: table-header-group !important; }
  #${ROOT_ID} > table.pp > tfoot { display: table-footer-group !important; }
  #${ROOT_ID} > table.pp > * > tr > td { padding: 0 !important; border: 0 !important; background: none !important; }
  #${ROOT_ID} .pp-sp { height: 10mm; }
  #${ROOT_ID} .pp-body > * {
    display: block !important; position: static !important;
    height: auto !important; max-height: none !important; min-height: 0 !important;
    overflow: visible !important; opacity: 1 !important; flex: none !important;
  }
  #${ROOT_ID} { font-size: 10px; }
  /* bỏ sticky của khung xem trước */
  #${ROOT_ID} thead th, #${ROOT_ID} tfoot td { position: static !important; }
  #${ROOT_ID} thead { display: table-header-group; }   /* tiêu đề cột lặp lại mỗi trang */
  #${ROOT_ID} tfoot { display: table-row-group; }      /* dòng tổng in 1 lần ở cuối */
  #${ROOT_ID} table { width: 100%; }
  /* khổ dọc (~190 mm): chữ nhỏ, ô bảng gọn để bảng 10 cột không tràn */
  #${ROOT_ID} th, #${ROOT_ID} td { padding: 4px 5px !important; font-size: 9.5px !important; white-space: normal; }
  #${ROOT_ID} .pill { font-size: 9px !important; padding: 0 5px !important; }
  #${ROOT_ID} .stv-row { grid-template-columns: 1fr !important; display: grid !important; }
  #${ROOT_ID} tr, #${ROOT_ID} .doc-si, #${ROOT_ID} .stv-panel, #${ROOT_ID} .stv-info { break-inside: avoid; }
  #${ROOT_ID} .doc-title, #${ROOT_ID} .rpt-sec-h { break-after: avoid; }
  /* sơ đồ container: in liền sau phần SI (không ngắt trang), nền trắng; từng khung không bị cắt đôi */
  #${ROOT_ID} .stv { background: #fff !important; padding: 8px 0; border: 0; }
  #${ROOT_ID} .stv-h { break-after: avoid; }
  /* căn thẳng 1 lề trái / phải: bỏ padding ngang của từng khối (khung xem trước cần, bản in thì không) */
  #${ROOT_ID} .doc { padding: 0 0 10px !important; border-bottom: 0 !important; }
  #${ROOT_ID} .stv { padding: 6px 0 !important; }
  #${ROOT_ID} .stv-h, #${ROOT_ID} .rpt-sec-h { padding-left: 0 !important; padding-right: 0 !important; }
  #${ROOT_ID} .rpt-table th:first-child, #${ROOT_ID} .rpt-table td:first-child { padding-left: 0 !important; }
  #${ROOT_ID} .rpt-table th:last-child, #${ROOT_ID} .rpt-table td:last-child { padding-right: 0 !important; }
}
`;

let busy = false;

/** el: phần tử chứa nội dung xem trước. title: tên file gợi ý (không đuôi). */
export function printReport(el, title) {
    if (!el || busy) return false;
    busy = true;

    cleanup();                                   // phòng lần trước chưa dọn
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = PRINT_CSS;
    document.head.appendChild(style);

    const root = document.createElement('div');
    root.id = ROOT_ID;
    const copy = el.cloneNode(true);
    copy.classList.remove('dim');
    copy.removeAttribute('id');
    copy.scrollTop = 0;
    // Bảng khung: thead / tfoot rỗng cao 10 mm lặp lại mỗi trang = lề trên / dưới
    const frame = document.createElement('table');
    frame.className = 'pp';
    frame.innerHTML = '<thead><tr><td><div class="pp-sp"></div></td></tr></thead>'
        + '<tbody><tr><td class="pp-body"></td></tr></tbody>'
        + '<tfoot><tr><td><div class="pp-sp"></div></td></tr></tfoot>';
    frame.querySelector('.pp-body').appendChild(copy);
    root.appendChild(frame);
    document.body.appendChild(root);

    const oldTitle = document.title;
    if (title) document.title = title;

    let done = false;
    const finish = () => {
        if (done) return;
        done = true;
        window.removeEventListener('afterprint', finish);
        document.title = oldTitle;
        cleanup();
    };
    window.addEventListener('afterprint', finish);

    // 2 frame để trình duyệt áp style mới rồi mới mở hộp thoại in
    // Dọn khi đóng hộp thoại in (afterprint). Safari không chặn ở print() -> KHÔNG dọn theo hẹn giờ;
    // root sót lại vẫn bị ẩn trên màn hình (display:none) và được dọn ở lần in sau.
    requestAnimationFrame(() => requestAnimationFrame(() => {
        try { window.print(); }
        finally { busy = false; }
    }));
    return true;
}

function cleanup() {
    document.getElementById(ROOT_ID)?.remove();
    document.getElementById(STYLE_ID)?.remove();
}
