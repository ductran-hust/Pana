using Swms.FinishGoods.Web.Features.Reports.Business;

namespace Swms.FinishGoods.Web.Features.Reports;

public static class ReportModule
{
    /// <summary>Màn Báo cáo. Hiện dùng MockReportBusiness (dữ liệu giả) — có API thì thay bằng
    /// services.AddApiClient&lt;IReportApi&gt;(api) + ReportBusiness.</summary>
    public static IServiceCollection AddReportFeature(this IServiceCollection services)
    {
        services.AddScoped<IReportBusiness, MockReportBusiness>();
        return services;
    }
}
