using System.Globalization;
using System.Net;
using System.Text;
using Microsoft.AspNetCore.Components;
using Swms.FinishGoods.Web.Features.Reports.Business.Models;
using Swms.FinishGoods.Web.Features.StowagePlan.App.Rendering;

namespace Swms.FinishGoods.Web.Features.Reports.App.Rendering;

/*  Phối cảnh 1 container đã đóng (Packing List) — SVG tĩnh, vẽ phía server (dùng được cho PDF).

    Khác IsoRenderer (isometric, hợp với 1 pallet / 1 cọc): container dài 12 m mà vẽ
    isometric thì gần vuông, nhỏ xíu trong khung ngang. Ở đây dùng phép chiếu xiên
    (cabinet): X dọc container chạy thẳng sang phải, chiều sâu Y chéo lên trên-phải,
    Z thẳng đứng → container nằm ngang, đầu cont bên trái, cửa bên phải, đọc như bản vẽ.

    Mặt thấy được: mặt trước (Y nhỏ), mặt trên, mặt phải (phía cửa).
    Thứ tự vẽ: xa trước (Y lớn), trái trước (X nhỏ), dưới trước (Z nhỏ).
    Màu mặt dùng IsoRenderer.Shade để cùng tông với Stowage Plan.                       */
public static class StowageSvg
{
    private const double DepthX = 0.42;     // 1 cm sâu -> lệch phải
    private const double DepthY = 0.30;     // 1 cm sâu -> lệch lên
    private const string WoodColor = "#C9A15A";
    private const string NoseColor = "#1976D2";   // = --accent-blue
    private const string DoorColor = "#C42B1C";   // = --danger

    public static MarkupString Render(ReportStowContainer c, string noseLabel, string doorLabel, string ariaLabel, string? focusSi = null, Func<int, string>? boxesText = null)
    {
        double L = c.Length, W = c.Width, H = c.Height;
        var sb = new StringBuilder(8192);

        static string F(double v) => v.ToString("0.#", CultureInfo.InvariantCulture);
        static string P(double x, double y, double z) => F(x + y * DepthX) + "," + F(-z - y * DepthY);

        void Poly(string fill, string stroke, double sw, params string[] pts) => PolyO(fill, 1, stroke, sw, pts);

        void PolyO(string fill, double opacity, string stroke, double sw, params string[] pts)
            => sb.Append("<polygon points=\"").Append(string.Join(' ', pts))
                 .Append("\" fill=\"").Append(fill)
                 .Append(opacity < 1 ? $"\" fill-opacity=\"{F(opacity)}" : "")
                 .Append("\" stroke=\"").Append(stroke)
                 .Append("\" stroke-width=\"").Append(F(sw)).Append("\" stroke-linejoin=\"round\"/>");

        void Line(string color, double sw, string? dash, params string[] pts)
            => sb.Append("<polyline fill=\"none\" points=\"").Append(string.Join(' ', pts))
                 .Append("\" stroke=\"").Append(color).Append("\" stroke-width=\"").Append(F(sw)).Append('"')
                 .Append(dash is null ? "" : $" stroke-dasharray=\"{dash}\"").Append("/>");

        void Box(double x, double y, double z, double l, double w, double h, string color, string? title, bool off)
        {
            const string stroke = "rgba(30,30,30,.45)";
            sb.Append(off ? "<g opacity=\".22\">" : "<g>");
            if (title is not null) sb.Append("<title>").Append(WebUtility.HtmlEncode(title)).Append("</title>");
            Poly(IsoRenderer.Shade(color, 0.95), stroke, .6,                                    // trước
                P(x, y, z), P(x + l, y, z), P(x + l, y, z + h), P(x, y, z + h));
            Poly(IsoRenderer.Shade(color, 1.18), stroke, .6,                                    // trên
                P(x, y, z + h), P(x + l, y, z + h), P(x + l, y + w, z + h), P(x, y + w, z + h));
            Poly(IsoRenderer.Shade(color, 0.72), stroke, .6,                                    // phải
                P(x + l, y, z), P(x + l, y + w, z), P(x + l, y + w, z + h), P(x + l, y, z + h));
            sb.Append("</g>");
        }

        // ── Phía sau: sàn, vách trong, vách đầu cont ──
        Poly("#EEF1F5", "#B8C1CE", .8, P(0, 0, 0), P(L, 0, 0), P(L, W, 0), P(0, W, 0));
        for (var x = 120.0; x < L; x += 120)                                                   // vạch 120 cm
            Line("#D3D9E2", .6, null, P(x, 0, 0), P(x, W, 0));
        Line("#8A97A8", .8, null, P(0, W, 0), P(0, W, H), P(L, W, H), P(L, W, 0));             // vách xa
        PolyO(NoseColor, .14, NoseColor, 1.2, P(0, 0, 0), P(0, W, 0), P(0, W, H), P(0, 0, H)); // đầu cont

        // ── Pallet: xa → gần, trái → phải, dưới → trên ──
        var blocks = new List<(double X, double Y, double Z, double L, double W, double H, string Color, string Title, bool Off)>();
        foreach (var col in c.Columns)
        {
            double z = 0;
            for (var i = 0; i < col.Pallets.Count; i++)
            {
                var p = col.Pallets[i];
                var tip = $"{col.Position} · {col.Code} · {p.Code} · {p.SiNo} · {p.Model} · {(boxesText?.Invoke(p.Boxes) ?? p.Boxes.ToString())} · {p.Weight:N0} kg";
                // Tìm theo SI: pallet của SI khác mờ đi
                var off = focusSi is not null && !string.Equals(p.SiNo, focusSi, StringComparison.OrdinalIgnoreCase);
                if (p.BaseHeight > 0)
                    blocks.Add((col.X, col.Y, z, col.L, col.W, p.BaseHeight, WoodColor, tip, off));
                blocks.Add((col.X + 1, col.Y + 1, z + p.BaseHeight, col.L - 2, col.W - 2, p.Height - p.BaseHeight - .5, p.Color, tip, off));
                z += p.Height;
            }
        }
        foreach (var b in blocks.OrderByDescending(b => b.Y).ThenBy(b => b.X).ThenBy(b => b.Z))
            Box(b.X, b.Y, b.Z, b.L, b.W, b.H, b.Color, b.Title, b.Off);

        // ── Phía trước: cạnh vỏ gần + khung cửa ──
        Line("#334D6E", 1.2, null, P(0, 0, 0), P(L, 0, 0));
        Line("#334D6E", 1, "5 4", P(0, 0, H), P(L, 0, H), P(L, W, H));
        Line("#334D6E", 1, "5 4", P(0, 0, 0), P(0, 0, H), P(0, W, H));
        Line(DoorColor, 1.6, null, P(L, 0, 0), P(L, 0, H), P(L, W, H), P(L, W, 0), P(L, 0, 0));

        // Nhãn đầu cont / cửa
        static string Esc(string s) => WebUtility.HtmlEncode(s.ToUpperInvariant());
        var (nx, ny) = (-8 + W * DepthX / 2, -H - W * DepthY - 12);
        sb.Append($"<text x=\"{F(nx)}\" y=\"{F(ny)}\" text-anchor=\"middle\" font-size=\"22\" font-weight=\"800\" fill=\"{NoseColor}\">{Esc(noseLabel)}</text>");
        var (dx, dy) = (L + W * DepthX / 2, -H - W * DepthY - 12);
        sb.Append($"<text x=\"{F(dx)}\" y=\"{F(dy)}\" text-anchor=\"middle\" font-size=\"22\" font-weight=\"800\" fill=\"{DoorColor}\">{Esc(doorLabel)}</text>");

        // khung nhìn: X 0 → L + W·DepthX, Y -(H + W·DepthY) → 0, chừa lề cho nhãn
        double minX = -60, minY = -H - W * DepthY - 44, w = L + W * DepthX + 120, h = H + W * DepthY + 56;
        return new MarkupString(
            $"<svg viewBox=\"{F(minX)} {F(minY)} {F(w)} {F(h)}\" preserveAspectRatio=\"xMidYMid meet\" role=\"img\" aria-label=\"{WebUtility.HtmlEncode(ariaLabel)}\" font-family=\"Be Vietnam Pro, system-ui, sans-serif\">{sb}</svg>");
    }
}
