// Báo cáo · in nội dung xem trước (ES module, import từ ReportDialog.razor).
//
// TẠM THỜI thay cho file PDF từ API: chép HTML đang hiện trong khung xem trước sang 1 iframe ẩn,
// kèm toàn bộ CSS của trang (tokens, theme, CSS isolation của Blazor — thuộc tính b-xxx đi theo
// HTML nên style scoped vẫn áp), rồi gọi print(). Người dùng chọn "Lưu dưới dạng PDF".
// document.title của iframe = tên file gợi ý khi lưu PDF.

const PRINT_CSS = `
@page { size: A4 landscape; margin: 10mm; }
html, body { margin: 0; background: #fff !important; }
* { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
.rpt-print { font-size: 11px; }
/* bỏ sticky / cuộn của khung xem trước */
.rpt-print thead th, .rpt-print tfoot td { position: static !important; }
.rpt-print thead { display: table-header-group; }      /* tiêu đề cột lặp lại mỗi trang */
.rpt-print tfoot { display: table-row-group; }         /* dòng tổng chỉ in 1 lần ở cuối */
.rpt-print table { width: 100%; }
.rpt-print tr, .rpt-print .doc-si, .rpt-print .stv-panel, .rpt-print .stv-info { break-inside: avoid; }
.rpt-print .doc-title { break-after: avoid; }
/* sơ đồ container: sang trang mới, nền trắng; danh sách pallet theo ngay sau */
.rpt-print .stv { break-before: page; background: #fff !important; padding: 0 0 8px; border: 0; }
.rpt-print .rpt-sec-h { break-after: avoid; }
.rpt-print [title] { cursor: default; }
`;

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/** el: phần tử chứa nội dung xem trước. title: tên file gợi ý (không đuôi). */
export function printReport(el, title) {
    if (!el) return false;

    const frame = document.createElement('iframe');
    frame.setAttribute('aria-hidden', 'true');
    Object.assign(frame.style, { position: 'fixed', right: '0', bottom: '0', width: '0', height: '0', border: '0' });
    document.body.appendChild(frame);

    // Giữ nguyên thuộc tính <body> (data-surface="web" -> tokens.css) và mọi stylesheet của trang
    const bodyAttrs = [...document.body.attributes].map(a => `${a.name}="${esc(a.value)}"`).join(' ');
    const styles = [...document.querySelectorAll('link[rel="stylesheet"], style')].map(n => n.outerHTML).join('\n');

    const doc = frame.contentDocument;
    doc.open();
    doc.write(`<!DOCTYPE html><html lang="${esc(document.documentElement.lang || 'vi')}"><head>
<meta charset="utf-8"><base href="${esc(document.baseURI)}"><title>${esc(title)}</title>
${styles}<style>${PRINT_CSS}</style></head>
<body ${bodyAttrs}><div class="rpt-print">${el.innerHTML}</div></body></html>`);
    doc.close();

    const win = frame.contentWindow;
    let done = false;
    const cleanup = () => setTimeout(() => frame.remove(), 500);
    const go = async () => {
        if (done) return;
        done = true;
        try { await doc.fonts?.ready; } catch { /* bỏ qua */ }
        win.focus();
        win.print();                 // chặn tới khi đóng hộp thoại in (Chrome / Edge)
        cleanup();
    };
    win.addEventListener('afterprint', cleanup);

    // Chờ stylesheet trong iframe tải xong (lấy từ cache nên nhanh); tối đa 2 giây
    const links = [...doc.querySelectorAll('link[rel="stylesheet"]')];
    Promise.all(links.map(l => l.sheet ? null : new Promise(r => { l.onload = l.onerror = r; })))
        .then(go);
    setTimeout(go, 2000);
    return true;
}
