using Swms.FinishGoods.Web.Features.Reports.Business.Models;
using Swms.FinishGoods.Web.Shared.Application.Models;

namespace Swms.FinishGoods.Web.Features.Reports.Business;

// Màn hình chỉ phụ thuộc interface này — đổi Mock <-> API thật ở ReportModule.
public interface IReportBusiness
{
    /// <summary>Xem trước: tối đa ReportPreview.PreviewLimit dòng + KPI + dòng tổng.</summary>
    Task<Result<ReportPreview>> GetPreviewAsync(ReportRequest request);

    /// <summary>Tải file đủ dữ liệu theo cùng tham số xem trước.</summary>
    Task<Result<ReportFile>> ExportAsync(ReportRequest request, ReportFormat format);
}
