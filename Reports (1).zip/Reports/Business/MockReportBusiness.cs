using System.Globalization;
using Swms.FinishGoods.Web.Features.Reports.Business.Models;
using Swms.FinishGoods.Web.Shared.Application.Models;
using Swms.FinishGoods.Web.Shared.Business.Base;

namespace Swms.FinishGoods.Web.Features.Reports.Business;

/*  MOCK — dựng UI trước khi có API báo cáo.
    Dữ liệu sinh ngẫu nhiên nhưng ỔN ĐỊNH theo tham số (cùng tham số -> cùng số),
    để bấm xem trước nhiều lần không nhảy số. Export trả Content = null -> UI báo "chưa có API".
    Có API: viết ReportBusiness gọi Refit, đổi đăng ký trong ReportModule.               */
public class MockReportBusiness : BaseBusiness, IReportBusiness
{
    public MockReportBusiness(ILogger<MockReportBusiness> logger, ErrorHandler errorHandler)
        : base(logger, errorHandler) { }

    public Task<Result<ReportPreview>> GetPreviewAsync(ReportRequest request)
        => ExecuteAsync(async () =>
        {
            await Task.Delay(350);
            return ReportMockData.Build(request);
        });

    public Task<Result<ReportFile>> ExportAsync(ReportRequest request, ReportFormat format)
        => ExecuteAsync(async () =>
        {
            await Task.Delay(600);
            var (ext, mime) = format == ReportFormat.Excel
                ? ("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                : ("pdf", "application/pdf");
            var def = ReportCatalog.Find(request.ReportKey);
            var period = def?.Ref == ReportRef.Trip ? (request.TripNo ?? request.SiNo)?.Trim().ToUpperInvariant() ?? ""
                : def?.Ref == ReportRef.Si ? request.SiNo?.Trim().ToUpperInvariant() ?? ""
                : def?.PickMonth == true ? request.Date.ToString("yyyyMM")
                : request.Date.ToString("yyyyMMdd");
            return new ReportFile($"swms_{request.ReportKey}_{period}.{ext}", mime, null);
        });
}

internal static class ReportMockData
{
    private static readonly string[] Models =
        { "NE-1054FAUH", "NE-1802V", "NE-1802VMC", "NN-ST34NB", "NN-CD87KS", "NE-FS301", "NN-GT35NB", "ARBDHD20016D" };

    private static readonly string[] Pickers = { "SCS-0412", "SCS-0187", "FA-0233", "SCS-0520" };

    private static ReportColumnKind Mono => ReportColumnKind.Mono;
    private static ReportColumnKind Num => ReportColumnKind.Number;
    private static ReportColumnKind St => ReportColumnKind.Status;

    public static ReportPreview Build(ReportRequest q)
    {
        var rnd = new Random(Seed(q));
        var p = q.ReportKey switch
        {
            "inbound_summary" => InboundSummary(q, rnd),
            "inbound_quality" => InboundQuality(q, rnd),
            "stock_morning" => StockMorning(q, rnd),
            "stock_monthend" => StockMonthEnd(q, rnd),
            "slow_moving" => SlowMoving(q, rnd),
            "kitting_tally" => KittingTally(q, rnd),
            "packing_list" => PackingList(q, rnd),
            _ => throw new InvalidOperationException($"Báo cáo '{q.ReportKey}' chưa có"),
        };
        return p.Doc is null ? WithDoc(p, q) : p;
    }

    /// <summary>Báo cáo dạng bảng: phần đầu = tên báo cáo + ngày của báo cáo + ngày in.</summary>
    private static ReportPreview WithDoc(ReportPreview p, ReportRequest q)
    {
        var def = ReportCatalog.Find(q.ReportKey)!;
        var refNo = def.PickMonth ? q.Date.ToString("MM/yyyy") : q.Date.ToString("dd/MM/yyyy");
        return new ReportPreview
        {
            Columns = p.Columns, Rows = p.Rows, TotalRows = p.TotalRows, Totals = p.Totals,
            Kpis = p.Kpis, GeneratedAt = p.GeneratedAt, Containers = p.Containers, SiInfos = p.SiInfos,
            Doc = new ReportDocHeader(def.TitleKey, def.DateLabelKey, refNo, null, null, null, DateTime.Now,
                                      def.HasAgeing ? q.AgeDays : null),
        };
    }

    // ── Nhập kho ────────────────────────────────────────────
    private static ReportPreview InboundSummary(ReportRequest q, Random rnd)
    {
        var cols = new List<ReportColumn>
        {
            new("date", Mono), new("model", Mono), new("category"), new("pallets", Num),
            new("boxes", Num), new("qty", Num), new("oqc", St), new("area", Mono),
        };
        var rows = new List<ReportCell[]>();
        int tp = 0, tb = 0, tq = 0;
        var models = new HashSet<string>();

        foreach (var d in Days(q))
            for (int i = 0, n = rnd.Next(12, 30); i < n; i++)
            {
                var m = Pick(rnd, Models);
                var p = rnd.Next(1, 12);
                var b = p * rnd.Next(8, 21);
                var qty = b * (m.StartsWith("NE") ? 1 : 2);
                var oqc = rnd.Next(10) switch
                {
                    < 6 => Key("Rpt.St.pass", "success"),
                    < 8 => Key("Rpt.St.pending", "dim"),
                    8 => Key("Rpt.St.inspecting", "warning"),
                    _ => Key("Rpt.St.ng", "danger"),
                };
                rows.Add(new ReportCell[] { D(d), m, Category(m), N(p), N(b), N(qty), oqc, $"RCV-{(char)('A' + rnd.Next(3))}" });
                tp += p; tb += b; tq += qty; models.Add(m);
            }

        return Make(cols, rows,
            new ReportCell[] { Key("Rpt.D.Total"), null, null, N(tp), N(tb), N(tq), null, null },
            new ReportKpi("pallets", tp.ToString("N0")), new ReportKpi("boxes", tb.ToString("N0")),
            new ReportKpi("qty", tq.ToString("N0")), new ReportKpi("models", models.Count.ToString()));
    }

    private static ReportPreview InboundQuality(ReportRequest q, Random rnd)
    {
        var cols = new List<ReportColumn>
        {
            new("prod_date", Mono), new("model", Mono), new("lot", Mono), new("boxes", Num),
            new("sample", Num), new("pass", Num), new("ng", Num), new("pass_rate", Num), new("result", St),
        };
        var rows = new List<ReportCell[]>();
        int lots = 0, lotPass = 0, lotNg = 0, ts = 0, tpass = 0, tng = 0;

        foreach (var d in Days(q))
            for (int i = 0, n = rnd.Next(8, 20); i < n; i++)
            {
                var m = Pick(rnd, Models);
                var boxes = rnd.Next(40, 320);
                var sample = Math.Max(3, boxes / 10);
                var ng = rnd.Next(8) == 0 ? rnd.Next(1, 4) : 0;
                var pending = rnd.Next(9) == 0;
                var pass = sample - ng;
                var result = pending ? Key("Rpt.St.pending", "dim")
                           : ng > 0 ? Key("Rpt.St.ng", "danger")
                           : Key("Rpt.St.pass", "success");

                rows.Add(new ReportCell[]
                {
                    D(d), m, $"L{d:MMdd}-{i + 1:00}", N(boxes),
                    N(sample), pending ? "—" : N(pass), pending ? "—" : N(ng),
                    pending ? "—" : Pct(pass, sample), result,
                });
                lots++;
                if (!pending) { ts += sample; tpass += pass; tng += ng; if (ng > 0) lotNg++; else lotPass++; }
            }

        return Make(cols, rows,
            new ReportCell[] { Key("Rpt.D.Total"), null, null, null, N(ts), N(tpass), N(tng), Pct(tpass, ts), null },
            new ReportKpi("lots", lots.ToString("N0")), new ReportKpi("lot_pass", lotPass.ToString("N0"), "success"),
            new ReportKpi("lot_ng", lotNg.ToString("N0"), lotNg > 0 ? "danger" : null), new ReportKpi("pass_rate", Pct(tpass, ts)));
    }

    // ── Tồn kho ─────────────────────────────────────────────
    private static ReportPreview StockMorning(ReportRequest q, Random rnd)
    {
        var cols = new List<ReportColumn>
        {
            new("area", Mono), new("locator", Mono), new("pallet", Mono), new("model", Mono),
            new("box_system", Num), new("box_count", Num), new("diff", Num), new("counted_by", Mono),
        };
        var rows = new List<ReportCell[]>();
        var locators = new HashSet<string>();
        int counted = 0, diffs = 0, tsys = 0, tcnt = 0;

        for (int i = 0, n = rnd.Next(40, 120); i < n; i++)
        {
            var area = $"STR-{(char)('A' + rnd.Next(3))}";
            var loc = $"{area[^1]}-{rnd.Next(1, 13):00}-{rnd.Next(1, 9):00}-{(rnd.Next(2) == 0 ? "A" : "B")}";
            var sys = rnd.Next(8, 41);
            int? cnt = rnd.Next(10) < 8 ? sys + (rnd.Next(12) == 0 ? rnd.Next(-2, 3) : 0) : null;
            var diff = cnt - sys;

            rows.Add(new ReportCell[]
            {
                area, loc, PalletId(rnd), Pick(rnd, Models), N(sys),
                cnt is { } c ? N(c) : Key("Rpt.St.not_counted", "dim"),
                diff is null ? "—" : diff == 0 ? "0" : new ReportCell(diff.Value.ToString("+0;-0"), "danger"),
                cnt is null ? null : Pick(rnd, Pickers),
            });
            locators.Add(loc);
            tsys += sys;
            if (cnt is { } cv) { counted++; tcnt += cv; if (diff != 0) diffs++; }
        }
        rows = rows.OrderBy(r => r[1].Text).ToList();

        return Make(cols, rows,
            new ReportCell[] { Key("Rpt.D.Total"), null, null, null, N(tsys), N(tcnt), null, null },
            new ReportKpi("locators", locators.Count.ToString("N0")), new ReportKpi("pallets", rows.Count.ToString("N0")),
            new ReportKpi("counted", Pct(counted, rows.Count)), new ReportKpi("diff_pallets", diffs.ToString("N0"), diffs > 0 ? "danger" : "success"));
    }

    private static ReportPreview StockMonthEnd(ReportRequest q, Random rnd)
    {
        var cols = new List<ReportColumn>
        {
            new("model", Mono), new("category"), new("opening", Num), new("in_qty", Num),
            new("out_qty", Num), new("closing", Num), new("pallets", Num), new("boxes", Num),
        };
        var rows = new List<ReportCell[]>();
        int to = 0, ti = 0, tx = 0, tc = 0, tp = 0, tb = 0;

        foreach (var m in Models)
        {
            var open = rnd.Next(500, 5000);
            var inQ = rnd.Next(800, 6000);
            var outQ = Math.Min(open + inQ, rnd.Next(600, 6500));
            var close = open + inQ - outQ;
            var boxes = close / (m.StartsWith("NE") ? 1 : 2);
            var pallets = (int)Math.Ceiling(boxes / 24.0);
            rows.Add(new ReportCell[] { m, Category(m), N(open), N(inQ), N(outQ), N(close), N(pallets), N(boxes) });
            to += open; ti += inQ; tx += outQ; tc += close; tp += pallets; tb += boxes;
        }

        return Make(cols, rows,
            new ReportCell[] { Key("Rpt.D.Total"), null, N(to), N(ti), N(tx), N(tc), N(tp), N(tb) },
            new ReportKpi("opening", to.ToString("N0")), new ReportKpi("in_qty", ti.ToString("N0"), "success"),
            new ReportKpi("out_qty", tx.ToString("N0"), "warning"), new ReportKpi("closing", tc.ToString("N0")));
    }

    private static ReportPreview SlowMoving(ReportRequest q, Random rnd)
    {
        var cols = new List<ReportColumn>
        {
            new("model", Mono), new("pallet", Mono), new("locator", Mono), new("prod_date", Mono),
            new("in_date", Mono), new("age_days", Num), new("qty", Num), new("age_group", St),
        };
        var asOf = q.Date.Date;
        var list = new List<(int Age, ReportCell[] Row)>();
        int tq = 0, over180 = 0;

        for (int i = 0, n = rnd.Next(25, 90); i < n; i++)
        {
            var age = q.AgeDays + rnd.Next(0, 300);
            var inDate = asOf.AddDays(-age);
            var prod = inDate.AddDays(-rnd.Next(0, 4));
            var qty = rnd.Next(8, 41);
            var group = age switch
            {
                >= 180 => new ReportCell("180+", "danger"),
                >= 90 => new ReportCell("90–179", "warning"),
                >= 60 => new ReportCell("60–89", "info"),
                _ => new ReportCell("30–59", "dim"),
            };
            list.Add((age, new ReportCell[]
            {
                Pick(rnd, Models), PalletId(rnd),
                $"{(char)('A' + rnd.Next(3))}-{rnd.Next(1, 13):00}-{rnd.Next(1, 9):00}-A",
                D(prod), D(inDate), N(age), N(qty), group,
            }));
            tq += qty;
            if (age >= 180) over180++;
        }
        var rows = list.OrderByDescending(x => x.Age).Select(x => x.Row).ToList();

        return Make(cols, rows,
            new ReportCell[] { Key("Rpt.D.Total"), null, null, null, null, null, N(tq), null },
            new ReportKpi("pallets", rows.Count.ToString("N0")), new ReportKpi("qty", tq.ToString("N0")),
            new ReportKpi("oldest", list.Count == 0 ? "—" : list.Max(x => x.Age).ToString("N0")),
            new ReportKpi("over180", over180.ToString("N0"), over180 > 0 ? "danger" : null));
    }

    // ── Xuất kho ────────────────────────────────────────────
    /*  Kitting tally = danh sách pallet / thùng / serial của 1 SI (chứng từ in, chỉ PDF).
        1 dòng = 1 thùng, mọi serial của thùng ghi chung 1 ô (cách nhau dấu phẩy).
        Pallet ID chỉ ghi ở dòng đầu của pallet — cho dễ đọc.
        Dữ liệu thật: pallet đã lấy cho SI (shipment_instruction_pallets / _boxes.picked_at)
        -> boxes -> box_lines (model, qty, serial_no).                                          */
    private static ReportPreview KittingTally(ReportRequest q, Random rnd)
    {
        var si = q.SiNo?.Trim().ToUpperInvariant();
        if (string.IsNullOrEmpty(si)) throw new InvalidOperationException("Kitting tally cần SI No");

        var cols = new List<ReportColumn>
        {
            new("pallet", Mono), new("box_no", Mono), new("model", Mono),
            new("qty", Num), new("serial", Mono), new("picked_at", Mono),
        };
        var rows = new List<ReportCell[]>();
        int pallets = rnd.Next(4, 12), boxes = 0, qty = 0, serialCount = 0;
        var t = DateTime.Today.AddHours(7).AddMinutes(rnd.Next(0, 60));     // lấy hàng từ đầu ca
        for (var p = 0; p < pallets; p++)
        {
            var pid = PalletId(rnd);
            var model = Pick(rnd, Models);
            var perBox = model.StartsWith("NE") ? 1 : 2;
            for (int b = 0, nb = rnd.Next(8, 25); b < nb; b++)
            {
                var boxNo = $"{rnd.Next(1000000000, int.MaxValue)}";
                t = t.AddSeconds(rnd.Next(20, 90));
                var serials = Enumerable.Range(0, perBox).Select(_ => $"{model[..2]}{rnd.Next(10000000, 99999999)}");
                rows.Add(new ReportCell[]
                {
                    b == 0 ? pid : "",
                    boxNo, model, N(perBox),
                    string.Join(", ", serials),                                 // mọi serial của thùng trên 1 dòng
                    t.ToString("dd/MM/yyyy HH:mm"),
                });
                boxes++;
                qty += perBox;
                serialCount += perBox;
            }
            t = t.AddMinutes(rnd.Next(3, 12));                                // đổi pallet
        }

        var r = Make(cols, rows,
            new ReportCell[] { Key("Rpt.D.Total"), N(boxes), null, N(qty), N(serialCount), null },
            new ReportKpi("pallets", pallets.ToString("N0")),
            new ReportKpi("boxes", boxes.ToString("N0")),
            new ReportKpi("qty", qty.ToString("N0")),
            new ReportKpi("serials", serialCount.ToString("N0")));
        return new ReportPreview
        {
            Columns = r.Columns, Rows = r.Rows, TotalRows = r.TotalRows, Totals = r.Totals,
            Kpis = r.Kpis, GeneratedAt = r.GeneratedAt,
            Doc = new ReportDocHeader("KITTING TALLY", "Rpt.Doc.Si", si, null, null, null, DateTime.Now),
            SiInfos = new() { MockSiInfo(si, rnd, pallets, boxes, qty, boxes * rnd.Next(12, 30)) },
        };
    }

    /// <summary>Thông tin SI mẫu — dữ liệu thật lấy từ chỉ thị xuất hàng (SiDetail).</summary>
    private static ReportSiInfo MockSiInfo(string si, Random rnd, int pallets, int boxes, int qty, double weight)
    {
        var etd = DateTime.Today.AddDays(rnd.Next(3, 8));
        var route = Pick(rnd, new[] { ("KOBE", "JAPAN", "PEX TLD"), ("HAMBURG", "GERMANY", "PME ERFURT"), ("LAEM CHABANG", "THAILAND", "PTL BKK") });
        return new ReportSiInfo(
            si, Pick(rnd, new[] { "First", "REV1", "REV2" }), Pick(rnd, new[] { "FCL", "LCL", "AIR" }),
            route.Item3, route.Item2, "FOB HAI PHONG", route.Item1,
            etd, etd.AddDays(rnd.Next(7, 30)), DateTime.Today,
            Pick(rnd, new[] { "VIETRANS", "NIPPON EXPRESS", "KWE" }), Pick(rnd, new[] { "ONE", "MSK", "SJJ" }),
            $"FX-{rnd.Next(100, 999)}N", rnd.Next(10000000, 99999999).ToString(),
            string.Join(", ", Enumerable.Range(0, rnd.Next(1, 3)).Select(_ => rnd.Next(80090000, 80099999))),
            Pick(rnd, new[] { "Hong Nhung Vu", "Thu Trang Le", "Minh Anh Tran" }),
            pallets, boxes, qty, weight);
    }

    /*  Packing List = chứng từ đóng container của 1 CHUYẾN XE (1 container, có thể nhiều SI):
        tiêu đề + thông tin từng SI, rồi
        container nào, chì nào, cọc nào ở vị trí nào, pallet nào (SI nào) tầng trên / dưới.
        Dữ liệu thật lấy từ Stowage Plan đã lưu của chuyến xe. Mock: 40HC, 2 làn × 10 hàng 120 cm.   */
    private static readonly string[] ModelColors = { "#5B8FF9", "#5AD8A6", "#F6BD16", "#9270CA", "#6DC8EC", "#FF9D4D" };

    private static ReportPreview PackingList(ReportRequest q, Random rnd)
    {
        var trip = q.TripNo?.Trim().ToUpperInvariant();
        var focus = q.SiNo?.Trim().ToUpperInvariant();
        if (string.IsNullOrEmpty(focus)) focus = null;
        if (string.IsNullOrEmpty(trip) && focus is null)
            throw new InvalidOperationException("Packing List cần mã chuyến xe hoặc SI No");
        // Tìm theo SI: dữ liệu thật = chuyến xe (stowage plan đã lưu) có chứa pallet của SI.
        // SI chưa xếp chuyến nào -> trả preview rỗng / báo không tìm thấy.
        trip ??= $"TR{DateTime.Today:yyMMdd}-{rnd.Next(1, 20):00}";

        const double L = 1203, W = 235, H = 269, PL = 120, PW = 100, LaneGap = 15, Base = 15;
        var models = Models.OrderBy(_ => rnd.Next()).Take(rnd.Next(2, 5)).ToList();
        string ColorOf(string m) => ModelColors[models.IndexOf(m) % ModelColors.Length];
        // 1 chuyến xe chở 1–3 SI; pallet cùng SI xếp liền nhau từ đầu cont
        var sis = Enumerable.Range(0, rnd.Next(1, 4))
            .Select(_ => $"MW{DateTime.Today:yyyyMM}J{rnd.Next(1, 30)}").Distinct().ToList();
        if (focus is not null && !sis.Contains(focus))
            sis[rnd.Next(sis.Count)] = focus;       // SI tra cứu nằm trong chuyến

        var cols = new List<ReportStowColumn>();
        var total = rnd.Next(14, 33);
        int left = total, colNo = 1;
        var perSi = sis.ToDictionary(x => x, _ => 1);
        for (var row = 0; row < 10 && left > 0; row++)
            for (var lane = 0; lane < 2 && left > 0; lane++)
            {
                var n = left >= 2 && rnd.Next(5) > 0 ? 2 : 1;      // phần lớn cọc đôi
                var si = sis[Math.Min(sis.Count - 1, (total - left) * sis.Count / total)];
                var pallets = new List<ReportStowPallet>();
                for (var k = 0; k < n; k++)
                {
                    var m = Pick(rnd, models);
                    var boxes = rnd.Next(12, 41);
                    pallets.Add(new ReportStowPallet(
                        $"{si}-P{perSi[si]++:00}", si, m, ColorOf(m), boxes, boxes * (m.StartsWith("NE") ? 1 : 2),
                        Base + rnd.Next(85, 111), rnd.Next(280, 640), Base));
                    left--;
                }
                var y = (W - PW * 2 - LaneGap) / 2 + lane * (PW + LaneGap);
                cols.Add(new ReportStowColumn($"C{colNo++:00}", $"{row + 1}{(lane == 0 ? "T" : "P")}",
                                              row * PL, y, PL, PW, pallets));
            }
        var containers = new List<ReportStowContainer>
        {
            new(trip, $"{Pick(rnd, new[] { "TCLU", "MSKU", "ONEU", "SEGU" })}{rnd.Next(1000000, 9999999)}",
                $"PSV{rnd.Next(100000, 999999)}", "40HC", L, W, H, cols),
        };

        var cols2 = new List<ReportColumn>
        {
            new("position", Mono), new("column", Mono), new("tier"),
            new("pallet", Mono), new("si_no", Mono), new("model", Mono), new("boxes", Num), new("qty", Num),
            new("weight", Num), new("height", Num),
        };
        var rows = new List<ReportCell[]>();
        int tb = 0, tq = 0; double tw = 0;
        foreach (var c in containers)
            foreach (var col in c.Columns)
                for (var i = col.Pallets.Count - 1; i >= 0; i--)        // trên trước, dưới sau — như nhìn cọc
                {
                    var pl = col.Pallets[i];
                    var tier = col.Pallets.Count == 1 ? Key("Rpt.Stow.Single", "dim")
                             : i == 0 ? Key("Rpt.Stow.Bottom", "info") : Key("Rpt.Stow.Top", "warning");
                    rows.Add(new ReportCell[]
                    {
                        col.Position, col.Code, tier, pl.Code, pl.SiNo, pl.Model,
                        N(pl.Boxes), N(pl.Qty), N((int)pl.Weight), N((int)pl.Height),
                    });
                    tb += pl.Boxes; tq += pl.Qty; tw += pl.Weight;
                }

        var p = Make(cols2, rows,
            new ReportCell[] { Key("Rpt.D.Total"), null, null, N(rows.Count), null, null, N(tb), N(tq), N((int)tw), null },
            new ReportKpi("si_count", sis.Count.ToString("N0")),
            new ReportKpi("pallets", rows.Count.ToString("N0")),
            new ReportKpi("qty", tq.ToString("N0")),
            new ReportKpi("weight", tw.ToString("N0")));
        // Thông tin SI — dữ liệu thật lấy từ chỉ thị xuất hàng (SiDetail) của từng SI trong chuyến
        var cont = containers[0];
        var allPallets = cont.Pallets.ToList();
        var etd = DateTime.Today.AddDays(rnd.Next(3, 8));
        var route = Pick(rnd, new[] { ("KOBE", "JAPAN", "PEX TLD"), ("HAMBURG", "GERMANY", "PME ERFURT"), ("LAEM CHABANG", "THAILAND", "PTL BKK") });
        // Cùng chuyến = cùng lô hàng: consignee, cảng, ETD/ETA, forwarder, PIC giống nhau; PO / invoice / PL riêng từng SI
        var eta = etd.AddDays(rnd.Next(7, 30));
        var fwd = Pick(rnd, new[] { "VIETRANS", "NIPPON EXPRESS", "KWE" });
        var car = Pick(rnd, new[] { "ONE", "MSK", "SJJ" });
        var pic = Pick(rnd, new[] { "Hong Nhung Vu", "Thu Trang Le", "Minh Anh Tran" });
        var infos = sis.Select(x =>
        {
            var ps = allPallets.Where(pl => pl.SiNo == x).ToList();
            return new ReportSiInfo(
                x, Pick(rnd, new[] { "First", "REV1", "REV2" }), "FCL",
                route.Item3, route.Item2, "FOB HAI PHONG", route.Item1,
                etd, eta, DateTime.Today, fwd, car,
                $"FX-{rnd.Next(100, 999)}N", rnd.Next(10000000, 99999999).ToString(),
                string.Join(", ", Enumerable.Range(0, rnd.Next(1, 3)).Select(_ => rnd.Next(80090000, 80099999))),
                pic, ps.Count, ps.Sum(pl => pl.Boxes), ps.Sum(pl => pl.Qty), ps.Sum(pl => pl.Weight));
        }).ToList();

        // Chứng từ cần đủ mọi pallet -> không cắt 50 dòng
        return new ReportPreview
        {
            Columns = p.Columns, Rows = rows, TotalRows = rows.Count, Totals = p.Totals,
            Kpis = p.Kpis, GeneratedAt = p.GeneratedAt, Containers = containers,
            Doc = new ReportDocHeader("PACKING LIST", "Rpt.Doc.Trip", trip, cont.ContainerNo, cont.Type, cont.SealNo, DateTime.Now),
            SiInfos = infos,
            FocusSi = focus,
        };
    }

    // ── helpers ─────────────────────────────────────────────
    private static ReportPreview Make(List<ReportColumn> cols, List<ReportCell[]> rows, ReportCell[]? totals,
                                      params ReportKpi[] kpis) => new()
    {
        Columns = cols,
        Rows = rows.Take(ReportPreview.PreviewLimit).ToList(),
        TotalRows = rows.Count,
        Totals = totals,
        Kpis = kpis.ToList(),
        GeneratedAt = DateTime.Now,
    };

    /// <summary>Báo cáo theo 1 ngày — giữ dạng danh sách để builder không phải đổi.</summary>
    private static IEnumerable<DateTime> Days(ReportRequest q)
    {
        yield return q.Date.Date;
    }

    private static string Category(string model) => model.StartsWith("AR") ? "Service part" : "Microwave";
    private static string PalletId(Random rnd) => $"30{rnd.Next(10000000, 99999999)}00";
    private static T Pick<T>(Random rnd, IReadOnlyList<T> list) => list[rnd.Next(list.Count)];
    private static ReportCell N(int v) => new(v.ToString("N0"));
    private static ReportCell D(DateTime d) => new(d.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture));
    private static ReportCell Key(string key, string? tone = null) => new(key, tone, true);
    private static string Pct(int a, int b) => b == 0 ? "—" : $"{a * 100.0 / b:0.0}%";

    // string.GetHashCode đổi theo mỗi lần chạy app -> tự băm để số ổn định
    private static int Seed(ReportRequest q)
    {
        var s = $"{q.ReportKey}|{q.Date:yyyyMMdd}|{q.SiNo}|{q.TripNo}|{q.AgeDays}";
        unchecked
        {
            var h = 17;
            foreach (var c in s) h = h * 31 + c;
            return h;
        }
    }
}
