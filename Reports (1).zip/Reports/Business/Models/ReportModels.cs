using Microsoft.Extensions.Localization;

namespace Swms.FinishGoods.Web.Features.Reports.Business.Models;

// ─────────────────────────────────────────────────────────────
//  Danh mục báo cáo + model xem trước / tải file.
//  Nhãn: Rpt.<key>.Title / Rpt.<key>.Desc / Rpt.Col.<col> / Rpt.Kpi.<kpi> (SharedResource).
//  Thêm báo cáo mới = thêm 1 dòng ReportCatalog.All + resource + nhánh trong business.
// ─────────────────────────────────────────────────────────────

public enum ReportGroup { Inbound, Stock, Outbound }

public enum ReportFormat { Excel, Pdf }

public sealed record ReportGroupInfo(ReportGroup Group, string Key, string IconSvg)
{
    public string TitleKey => $"Rpt.Group.{Key}";
    public string DescKey => $"Rpt.Group.{Key}.Desc";
}

/// <summary>Chọn 1 ngày, riêng PickMonth = true chọn 1 tháng. DateLabelKey: nhãn ô ngày / tháng.</summary>
public sealed record ReportDef(string Key, ReportGroup Group, string DateLabelKey, string IconSvg)
{
    /// <summary>Chọn tháng thay vì ngày (tồn cuối tháng). Request.Date = ngày cuối tháng đó.</summary>
    public bool PickMonth { get; init; }
    /// <summary>Mã tham chiếu BẮT BUỘC nhập trước khi xem / tải:
    /// Si = SI No (Kitting tally), Trip = mã chuyến xe (Packing List). None = không có.</summary>
    public ReportRef Ref { get; init; }
    /// <summary>Cách tra cứu thứ 2 (None = không có). Packing List: Ref = Trip, AltRef = Si —
    /// nhập SI No -> tìm chuyến xe chứa SI đó, in Packing List của chuyến, làm nổi pallet của SI.</summary>
    public ReportRef AltRef { get; init; }
    public ReportRef[] RefModes => AltRef == ReportRef.None ? new[] { Ref } : new[] { Ref, AltRef };
    /// <summary>false = không chọn ngày (báo cáo theo SI / chuyến xe: mã đã xác định dữ liệu).</summary>
    public bool HasDate { get; init; } = true;
    /// <summary>Định dạng được tải. Mọi báo cáo là bản in -> mặc định chỉ PDF.</summary>
    public ReportFormat[] Formats { get; init; } = { ReportFormat.Pdf };
    /// <summary>Có chọn ngưỡng tuổi hàng (slow moving).</summary>
    public bool HasAgeing { get; init; }
    /// <summary>Nút chọn nhanh thêm (ngoài Hôm nay / Hôm qua), hiện chưa báo cáo nào dùng.</summary>
    public string[] ExtraPresets { get; init; } = Array.Empty<string>();

    public string TitleKey => $"Rpt.{Key}.Title";
    public string DescKey => $"Rpt.{Key}.Desc";
}

public static class ReportCatalog
{
    private const string IcInbound = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M12 3v12M7 10l5 5 5-5'/><path d='M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2'/></svg>";
    private const string IcStock = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M21 16V8l-9-5-9 5v8l9 5 9-5z'/><path d='M3.3 7 12 12l8.7-5M12 22V12'/></svg>";
    private const string IcOutbound = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M1 3h15v13H1z'/><path d='M16 8h4l3 3v5h-7z'/><circle cx='5.5' cy='18.5' r='2.5'/><circle cx='18.5' cy='18.5' r='2.5'/></svg>";

    private const string IcSum = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M3 3v18h18'/><path d='M7 15l4-4 3 3 5-6'/></svg>";
    private const string IcQuality = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M12 2 4 5v6c0 5 3.4 9.4 8 11 4.6-1.6 8-6 8-11V5z'/><path d='m9 12 2 2 4-4'/></svg>";
    private const string IcMorning = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><circle cx='12' cy='12' r='4'/><path d='M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4'/></svg>";
    private const string IcMonth = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><rect x='3' y='4' width='18' height='18' rx='2'/><path d='M16 2v4M8 2v4M3 10h18M8 14h2M14 14h2M8 18h2'/></svg>";
    private const string IcSlow = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><circle cx='12' cy='13' r='8'/><path d='M12 9v4l2 2M9 2h6'/></svg>";
    private const string IcKitting = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2'/><rect x='9' y='3' width='6' height='4' rx='1'/><path d='m9 14 2 2 4-4'/></svg>";
    private const string IcFinal = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><rect x='2' y='6' width='20' height='13' rx='1'/><path d='M6 6v13M10 6v13M14 6v13M18 6v13'/></svg>";

    public static readonly IReadOnlyList<ReportGroupInfo> Groups = new List<ReportGroupInfo>
    {
        new(ReportGroup.Inbound,  "inbound",  IcInbound),
        new(ReportGroup.Stock,    "stock",    IcStock),
        new(ReportGroup.Outbound, "outbound", IcOutbound),
    };

    public static readonly IReadOnlyList<ReportDef> All = new List<ReportDef>
    {
        // Nhập kho
        new("inbound_summary", ReportGroup.Inbound, "Rpt.D.InDate", IcSum),
        new("inbound_quality", ReportGroup.Inbound, "Rpt.D.QcDate", IcQuality),
        // Tồn kho
        new("stock_morning",  ReportGroup.Stock, "Rpt.D.CountDay", IcMorning),
        new("stock_monthend", ReportGroup.Stock, "Rpt.D.Month",    IcMonth) { PickMonth = true },
        new("slow_moving",    ReportGroup.Stock, "Rpt.D.AsOf",     IcSlow)  { HasAgeing = true },
        // Xuất kho
        new("kitting_tally", ReportGroup.Outbound, "Rpt.D.VanningDay", IcKitting)
        {
            Ref = ReportRef.Si, HasDate = false,
        },
        new("packing_list",  ReportGroup.Outbound, "Rpt.D.VanningDay", IcFinal)
        {
            Ref = ReportRef.Trip, AltRef = ReportRef.Si, HasDate = false,
        },
    };

    public static readonly int[] AgeingOptions = { 30, 60, 90, 180 };

    public static IEnumerable<ReportDef> InGroup(ReportGroup g) => All.Where(r => r.Group == g);
    public static ReportGroupInfo GroupOf(ReportDef r) => Groups.First(g => g.Group == r.Group);
    public static ReportDef? Find(string key) => All.FirstOrDefault(r => r.Key == key);
}

// ── Request ─────────────────────────────────────────────────
public class ReportRequest
{
    public string ReportKey { get; set; } = "";
    /// <summary>Ngày báo cáo (theo nghĩa của từng báo cáo — ReportDef.DateLabelKey). Báo cáo HasDate = false bỏ qua.
    /// Báo cáo chọn tháng: ngày cuối tháng (vd. 31/10/2026 = tháng 10/2026).</summary>
    public DateTime Date { get; set; }
    /// <summary>SI No (Kitting tally).</summary>
    public string? SiNo { get; set; }
    /// <summary>Mã chuyến xe (Packing List).</summary>
    public string? TripNo { get; set; }
    /// <summary>Slow moving: chỉ lấy pallet tồn ≥ N ngày.</summary>
    public int AgeDays { get; set; } = 90;
}

// ── Xem trước ───────────────────────────────────────────────
public enum ReportColumnKind { Text, Mono, Number, Status }

public sealed record ReportColumn(string Key, ReportColumnKind Kind = ReportColumnKind.Text)
{
    public string HeaderKey => $"Rpt.Col.{Key}";
    public bool AlignRight => Kind == ReportColumnKind.Number;
}

/// <summary>1 ô. Tone (success | warning | danger | info | dim) -> vẽ pill. IsKey = Text là key resource.</summary>
public sealed record ReportCell(string? Text, string? Tone = null, bool IsKey = false)
{
    public static implicit operator ReportCell(string? text) => new(text);
}

public sealed record ReportKpi(string Key, string Value, string? Tone = null)
{
    public string LabelKey => $"Rpt.Kpi.{Key}";
}

public sealed class ReportPreview
{
    public List<ReportColumn> Columns { get; init; } = new();
    /// <summary>Tối đa PreviewLimit dòng — file tải về có đủ.</summary>
    public List<ReportCell[]> Rows { get; init; } = new();
    public int TotalRows { get; init; }
    /// <summary>Dòng tổng (null = không có).</summary>
    public ReportCell[]? Totals { get; init; }
    public List<ReportKpi> Kpis { get; init; } = new();
    public DateTime GeneratedAt { get; init; } = DateTime.Now;
    /// <summary>Tiêu đề chứng từ (Packing List). null = báo cáo dạng bảng thường, không có phần đầu.</summary>
    public ReportDocHeader? Doc { get; init; }
    /// <summary>SI đang tra cứu (Packing List tìm theo SI): làm nổi SI này, mờ các SI khác cùng chuyến.</summary>
    public string? FocusSi { get; init; }
    /// <summary>Thông tin các SI trong chứng từ (Packing List).</summary>
    public List<ReportSiInfo>? SiInfos { get; init; }
    /// <summary>Sơ đồ đóng container (Packing List). null = báo cáo không có sơ đồ.</summary>
    public List<ReportStowContainer>? Containers { get; init; }

    public const int PreviewLimit = 50;
}

// ── Chứng từ Packing List ───────────────────────────────────
/// <summary>Phần đầu chứng từ — MỌI báo cáo đều có. Title: chữ in (PACKING LIST) hoặc key resource
/// (Rpt.xxx.Title, in hoa khi hiển thị). Số tham chiếu
/// (RefLabelKey: "Chuyến xe" / "SI No" / "Ngày nhập"…), container + chì nếu có, ngày in.</summary>
public sealed record ReportDocHeader(
    string Title, string RefLabelKey, string RefNo,
    string? ContainerNo, string? ContainerType, string? SealNo, DateTime PrintedAt,
    int? AgeDays = null);   // slow moving: ngưỡng tuổi hàng, UI ghép "≥ n ngày" theo ngôn ngữ

/// <summary>Thông tin 1 SI trên Packing List (lấy từ chỉ thị xuất hàng) + tổng của SI trong chuyến.</summary>
public sealed record ReportSiInfo(
    string SiNo, string? Revision, string? ShipMode,
    string? ConsigneeCode, string? CountryCode, string? PortOfLoading, string? PortOfDischarge,
    DateTime? EtdDate, DateTime? EtaDate, DateTime? VanningDate,
    string? ForwarderCode, string? CarrierCode,
    string? PoNos, string? InvoiceNo, string? PackingListNos, string? PicName,
    int Pallets, int Boxes, int Qty, double Weight);

// ── Sơ đồ đóng container (Packing List) ─────────────────────
// Toạ độ cm, cùng quy ước Stowage Plan: X dọc container tính từ đầu (mũi) ra cửa,
// Y ngang tính từ vách trái, Z lên trên. Dữ liệu thật: Stowage Plan đã lưu của chuyến xe
// (cọc + vị trí), số container / số chì của chuyến xe.

/// <summary>1 container của chuyến xe. Length / Width / Height: lòng trong (cm).</summary>
public sealed record ReportStowContainer(
    string TripNo, string ContainerNo, string? SealNo, string Type,
    double Length, double Width, double Height,
    List<ReportStowColumn> Columns)
{
    public IEnumerable<ReportStowPallet> Pallets => Columns.SelectMany(c => c.Pallets);
    public IEnumerable<string> SiNos => Pallets.Select(p => p.SiNo).Distinct(StringComparer.OrdinalIgnoreCase);
    public double Weight => Pallets.Sum(p => p.Weight);
    /// <summary>Khối lượng nửa trái / nửa phải (theo tâm cọc).</summary>
    public (double Left, double Right) LaneWeight
        => (Columns.Where(c => c.Y + c.W / 2 < Width / 2).Sum(c => c.Weight),
            Columns.Where(c => c.Y + c.W / 2 >= Width / 2).Sum(c => c.Weight));
}

/// <summary>1 cọc trên sàn. Position: nhãn vị trí (1T, 1P…). Pallets: dưới lên trên.</summary>
public sealed record ReportStowColumn(
    string Code, string Position, double X, double Y, double L, double W,
    List<ReportStowPallet> Pallets)
{
    public double Weight => Pallets.Sum(p => p.Weight);
    public double Height => Pallets.Sum(p => p.Height);
}

/// <summary>Height = tổng cao pallet (gồm đế BaseHeight). Color: màu model trên sơ đồ.</summary>
public sealed record ReportStowPallet(
    string Code, string SiNo, string Model, string Color, int Boxes, int Qty,
    double Height, double Weight, double BaseHeight);

/// <summary>Content null = API chưa trả file (mock).</summary>
public sealed record ReportFile(string FileName, string ContentType, byte[]? Content);

// ── Helper hiển thị ─────────────────────────────────────────
public static class ReportDisplay
{
    /// <summary>Key chưa có resource -> hiện fallback (mặc định là chính key).</summary>
    public static string Loc(IStringLocalizer L, string key, string? fallback = null)
    {
        var v = L[key];
        return v.ResourceNotFound ? fallback ?? key : v.Value;
    }

    public static string CellText(ReportCell c, IStringLocalizer L)
        => c.Text is null ? "—" : c.IsKey ? Loc(L, c.Text) : c.Text;

    public static string GroupPill(ReportGroup g) => g switch
    {
        ReportGroup.Inbound => "success",
        ReportGroup.Stock => "info",
        _ => "warning",
    };
}
